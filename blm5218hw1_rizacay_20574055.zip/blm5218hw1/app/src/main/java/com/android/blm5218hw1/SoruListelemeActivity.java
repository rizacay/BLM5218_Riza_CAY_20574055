package com.android.blm5218hw1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import java.util.ArrayList;

public class SoruListelemeActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<Sorular> liste;
    private SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_question);
        db = this.openOrCreateDatabase("Sinavdb", MODE_PRIVATE, null);
        recyclerView=findViewById(R.id.recyclerView);
        liste=getAllQuestions();

        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(linearLayoutManager);

        SorularAdapter adapter=new SorularAdapter(liste,this);
        recyclerView.setAdapter(adapter);
    }

    public ArrayList<Sorular> getAllQuestions() {
        ArrayList<Sorular> questionList = new ArrayList<>();

        Cursor c = db.rawQuery("SELECT * FROM " + TblSorular.TABLE_NAME, null);
        if (c.moveToFirst()) {
            do {
                Sorular question = new Sorular();
                question.setID(c.getInt(c.getColumnIndex(TblSorular.COLUMN_ID)));
                question.setSoru(c.getString(c.getColumnIndex(TblSorular.COLUMN_QUESTION)));
                question.setSecenekA(c.getString(c.getColumnIndex(TblSorular.COLUMN_OPTION1)));
                question.setSecenekB(c.getString(c.getColumnIndex(TblSorular.COLUMN_OPTION2)));
                question.setSecenekC(c.getString(c.getColumnIndex(TblSorular.COLUMN_OPTION3)));
                question.setSecenekD(c.getString(c.getColumnIndex(TblSorular.COLUMN_OPTION4)));
                question.setDogruSecenek(c.getString(c.getColumnIndex(TblSorular.COLUMN_ANSWER_NR)));
                question.setZorlukSeviyesi(c.getString(c.getColumnIndex(TblSorular.COLUMN_DIFF_LEVEL)));
                questionList.add(question);
            } while (c.moveToNext());
        }
        c.close();
        return questionList;
    }
    public static class TblSorular {
        public static final String TABLE_NAME = "TblSorular";
        public static final String COLUMN_ID = "id";
        public static final String COLUMN_QUESTION = "soru";
        public static final String COLUMN_OPTION1 = "secenekA";
        public static final String COLUMN_OPTION2 = "secenekB";
        public static final String COLUMN_OPTION3 = "secenekC";
        public static final String COLUMN_OPTION4 = "secenekD";
        public static final String COLUMN_ANSWER_NR = "dogruSecenek";
        public static final String COLUMN_DIFF_LEVEL = "zorlukSeviyesi";
    }
}