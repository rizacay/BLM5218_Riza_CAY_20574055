package com.android.blm5218hw1;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import static android.content.Context.MODE_PRIVATE;

public class SinavDbHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "Sinavdb";
    private static final int DATABASE_VERSION = 1;
    private SQLiteDatabase db;
    ContentValues cv;

    public SinavDbHelper(@Nullable Context context, int version) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        db = context.openOrCreateDatabase("Sinavdb", MODE_PRIVATE, null);
        onCreate(db);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        this.db = db;
        final String SQL_CREATE_QUESTIONS_TABLE = "CREATE TABLE IF NOT EXISTS " +
                TblSorular.TABLE_NAME + " ( " +
                TblSorular.COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                TblSorular.COLUMN_QUESTION + " TEXT, " +
                TblSorular.COLUMN_OPTION1 + " TEXT, " +
                TblSorular.COLUMN_OPTION2 + " TEXT, " +
                TblSorular.COLUMN_OPTION3 + " TEXT, " +
                TblSorular.COLUMN_OPTION4 + " TEXT, " +
                TblSorular.COLUMN_ANSWER_NR + " TEXT, " +
                TblSorular.COLUMN_DIFF_LEVEL + " TEXT " +
                ")";
        db.execSQL(SQL_CREATE_QUESTIONS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TblSorular.TABLE_NAME);
        onCreate(db);
    }

    public void soruekle(Sorular question) {
        cv = new ContentValues();
        cv.put(TblSorular.COLUMN_QUESTION, question.getSoru());
        cv.put(TblSorular.COLUMN_OPTION1, question.getSecenekA());
        cv.put(TblSorular.COLUMN_OPTION2, question.getSecenekB());
        cv.put(TblSorular.COLUMN_OPTION3, question.getSecenekC());
        cv.put(TblSorular.COLUMN_OPTION4, question.getSecenekD());
        cv.put(TblSorular.COLUMN_ANSWER_NR, question.getDogruSecenek());
        cv.put(TblSorular.COLUMN_DIFF_LEVEL, question.getZorlukSeviyesi());
        db.insert(TblSorular.TABLE_NAME, null, cv);
    }


    public long soruGuncelle(Sorular question, int guncellenecekId) {
        cv = new ContentValues();
        cv.put(TblSorular.COLUMN_QUESTION, question.getSoru());
        cv.put(TblSorular.COLUMN_OPTION1, question.getSecenekA());
        cv.put(TblSorular.COLUMN_OPTION2, question.getSecenekB());
        cv.put(TblSorular.COLUMN_OPTION3, question.getSecenekC());
        cv.put(TblSorular.COLUMN_OPTION4, question.getSecenekD());
        cv.put(TblSorular.COLUMN_ANSWER_NR, question.getDogruSecenek());
        cv.put(TblSorular.COLUMN_DIFF_LEVEL, question.getZorlukSeviyesi());
        long result = db.update(TblSorular.TABLE_NAME, cv, "id=?", new String[]{String.valueOf(guncellenecekId)});
        return result;
    }

    public void deleteQuestion(int id) {
        db.execSQL("DELETE FROM " + TblSorular.TABLE_NAME + " WHERE " + TblSorular.COLUMN_ID + "=" + id);
    }

    public Sorular guncellenecekSoruGetir(int id) {
        Sorular question;
        db = getReadableDatabase();
        String[] ids = {String.valueOf(id)};
        Cursor c =
                db.rawQuery("SELECT * FROM " + TblSorular.TABLE_NAME + " WHERE " + TblSorular.COLUMN_ID + "=?", ids);

        c.moveToFirst();
        question = new Sorular();
        question.setSoru(c.getString(c.getColumnIndex(TblSorular.COLUMN_QUESTION)));
        question.setSecenekA(c.getString(c.getColumnIndex(TblSorular.COLUMN_OPTION1)));
        question.setSecenekB(c.getString(c.getColumnIndex(TblSorular.COLUMN_OPTION2)));
        question.setSecenekC(c.getString(c.getColumnIndex(TblSorular.COLUMN_OPTION3)));
        question.setSecenekD(c.getString(c.getColumnIndex(TblSorular.COLUMN_OPTION4)));
        question.setDogruSecenek(c.getString(c.getColumnIndex(TblSorular.COLUMN_ANSWER_NR)));
        question.setZorlukSeviyesi(c.getString(c.getColumnIndex(TblSorular.COLUMN_DIFF_LEVEL)));

        c.close();
        return question;
    }

    public static class TblSorular {
        public static final String TABLE_NAME = "TblSorular";
        public static final String COLUMN_ID = "id";
        public static final String COLUMN_QUESTION = "soru";
        public static final String COLUMN_OPTION1 = "secenekA";
        public static final String COLUMN_OPTION2 = "secenekB";
        public static final String COLUMN_OPTION3 = "secenekC";
        public static final String COLUMN_OPTION4 = "secenekD";
        public static final String COLUMN_ANSWER_NR = "dogruSecenek";
        public static final String COLUMN_DIFF_LEVEL = "zorlukSeviyesi";
    }

}
