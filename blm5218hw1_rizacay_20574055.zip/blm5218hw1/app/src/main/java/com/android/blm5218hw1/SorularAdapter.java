package com.android.blm5218hw1;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class SorularAdapter extends RecyclerView.Adapter<SorularAdapter.RecyclerViewHolder> {
    ArrayList<Sorular> sorularArrayList;
    Context context;

    public SorularAdapter(ArrayList<Sorular> sorularArrayList, Context context) {
        this.sorularArrayList = sorularArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.layout_recyclerview_row, parent, false);
        return new RecyclerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, final int position) {
        holder.tvSoru.setText((position+1)+" ) "+ sorularArrayList.get(position).getSoru());
        holder.tvDogruSecenek.setText(sorularArrayList.get(position).getDogruSecenek());
        holder.tvA.setText(sorularArrayList.get(position).getSecenekA());
        holder.tvB.setText(sorularArrayList.get(position).getSecenekB());
        holder.tvC.setText(sorularArrayList.get(position).getSecenekC());
        holder.tvD.setText(sorularArrayList.get(position).getSecenekD());
        holder.tvZorlukSeviyesi.setText(sorularArrayList.get(position).getZorlukSeviyesi());
        holder.btnSil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle("Silme İşlemi Onayı!");
                builder.setMessage(position+1 + ". Soruyu silmek istediğinize emin misiniz?");
                builder.setIcon(android.R.drawable.ic_menu_delete);
                builder.setCancelable(false);
                builder.setPositiveButton("Evet", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        SinavDbHelper helper = new SinavDbHelper(context, 1);
                        helper.deleteQuestion(sorularArrayList.get(position).getID());
                        sorularArrayList.remove(position);
                        notifyItemRemoved(position);
                        notifyItemRangeChanged(position, sorularArrayList.size());
                        Toast.makeText(context, "Soru Silindi.", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.setNegativeButton("Hayır", null);
                builder.show();
            }
        });
        holder.btnGuncelle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, SoruGuncelleActivity.class);
                intent.putExtra("idUpdate", sorularArrayList.get(position).getID());
                context.startActivity(intent);
                Toast.makeText(context, "Güncelleme+"+ sorularArrayList.get(position).getID(), Toast.LENGTH_SHORT).show();
            }
        });

    }

    @Override
    public int getItemCount() {
        return sorularArrayList.size();
    }


    public class RecyclerViewHolder extends RecyclerView.ViewHolder {

        TextView tvSoru, tvDogruSecenek, tvA, tvB, tvC, tvD, tvZorlukSeviyesi;
        Button btnSil, btnGuncelle;

        public RecyclerViewHolder(@NonNull View itemView) {
            super(itemView);

            tvSoru = itemView.findViewById(R.id.tvSoru);
            tvDogruSecenek = itemView.findViewById(R.id.tvDogruSecenek);
            tvA = itemView.findViewById(R.id.tvA);
            tvB = itemView.findViewById(R.id.tvB);
            tvC = itemView.findViewById(R.id.tvC);
            tvD = itemView.findViewById(R.id.tvD);
            tvZorlukSeviyesi = itemView.findViewById(R.id.tvZorlukSeviyesi);
            btnSil = itemView.findViewById(R.id.btnSil);
            btnGuncelle = itemView.findViewById(R.id.btnGuncelle);
        }
    }
}
