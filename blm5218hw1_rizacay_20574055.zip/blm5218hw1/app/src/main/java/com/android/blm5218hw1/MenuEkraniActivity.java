package com.android.blm5218hw1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MenuEkraniActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_screen);
    }

    public void btnSinavAyarlariClick(View view) {
        Intent intent=new Intent(getApplicationContext(), SinavAyarActivity.class);
        startActivity(intent);
    }

    public void btnSoruEkleClick(View view) {
        Intent intent=new Intent(getApplicationContext(),SoruEkleActivity.class);
        startActivity(intent);
    }

    public void btnSoruListeleClick(View view) {
        Intent intent=new Intent(getApplicationContext(), SoruListelemeActivity.class);
        startActivity(intent);
    }

    public void btnSinavOlusturClick(View view) {
        Intent intent=new Intent(getApplicationContext(), SinavOlusturActivity.class);
        startActivity(intent);
    }
}