package com.android.blm5218hw1;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

import androidx.appcompat.app.AppCompatActivity;

public class KullaniciKayitActivity extends AppCompatActivity {

    EditText etAd, etSoyad, etTel, etEmail, etSifre, etSifreTekrar;
    String ad, soyad, tel, email, sifre, sifreTekrar;

    private ArrayList<Kullanicilar> kullanicilar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_signup);
        etAd = findViewById(R.id.etAd);
        etSoyad = findViewById(R.id.etSoyad);
        etTel = findViewById(R.id.etTel);
        etEmail = findViewById(R.id.etEmailLogin);
        etSifre = findViewById(R.id.etSifreLogin);
        etSifreTekrar = findViewById(R.id.etSifreTekrar);
        try {
            SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(this);
            String jsonString = pref.getString("spAyarlar", "");
            Gson gson = new Gson();
            Type type = new TypeToken<ArrayList<Kullanicilar>>() {
            }.getType();
            kullanicilar = gson.fromJson(jsonString, type);

        } catch (Exception e) {
            e.printStackTrace();
        }
        if (kullanicilar == null)
            kullanicilar = new ArrayList<>();
    }

    public void btnKayitOlClick(View view) {
        ad = etAd.getText().toString();
        soyad = etSoyad.getText().toString();
        tel = etTel.getText().toString();
        email = etEmail.getText().toString();
        sifre = etSifre.getText().toString();
        sifreTekrar = etSifreTekrar.getText().toString();
        if (ad.isEmpty() || soyad.isEmpty() || tel.isEmpty() || email.isEmpty() || sifre.isEmpty() || sifreTekrar.isEmpty()) {
            Toast.makeText(this, "Tüm alanları eksiksiz doldurunuz.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!sifre.equals(sifreTekrar)) {
            Toast.makeText(this, "Şifreniz eşleşmedi. Kontrol ediniz.", Toast.LENGTH_SHORT).show();
            return;
        } else {
            Kullanicilar kullanici1 = new Kullanicilar(ad, soyad, tel, email, sifre);
            if (!ayniEmailliKullanici(email)) {
                kullanicilar.add(kullanici1);
                Toast.makeText(this, "Kayıt Başarılı. Giriş Yapabilirsiniz.", Toast.LENGTH_SHORT).show();
                Gson gson = new Gson();
                String jsonString = gson.toJson(kullanicilar);
                SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(this);
                SharedPreferences.Editor editor = pref.edit();
                editor.putString("spAyarlar", jsonString);
                editor.apply();
                Intent i=new Intent(getApplicationContext(),KullaniciGirisActivity.class);
                startActivity(i);
            } else {
                Toast.makeText(this, "Bu üye kayıtlı!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private boolean ayniEmailliKullanici(String email) {
        boolean deger = false;
        for (Kullanicilar kullanici : kullanicilar) {
            if (kullanici.getEmail().equals(email)) {
                deger = true;
            } else {
                deger = false;
            }
        }
        return deger;
    }
}