package com.android.blm5218hw1;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SoruEkleActivity extends AppCompatActivity {

    EditText etSoruMetni, etSecenekA, etSecenekB, etSecenekC, etSecenekD;
    Spinner spnSecenek, spnZorlukSeviyesi;
    String soruMetni, secenekA, secenekB, secenekC, secenekD, dogruSecenek, zorlukSeviyesi;
    SQLiteDatabase db;
    SinavDbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_question);
        etSoruMetni = findViewById(R.id.etSoruMetni);
        etSecenekA = findViewById(R.id.etSecenekA);
        etSecenekB = findViewById(R.id.etSecenekB);
        etSecenekC = findViewById(R.id.etSecenekC);
        etSecenekD = findViewById(R.id.etSecenekD);
        spnSecenek = findViewById(R.id.spnSecenek);
        spnZorlukSeviyesi = findViewById(R.id.spnZorlukSeviyesi);
        dbHelper = new SinavDbHelper(this, 1);
    }

    @Override
    protected void onResume() {
        db = this.openOrCreateDatabase("Sinavdb", MODE_PRIVATE, null);
        dbHelper = new SinavDbHelper(this, 1);
        super.onResume();
    }

    public void btnSoruEkleClick(View view) {

        soruMetni = etSoruMetni.getText().toString();
        secenekA = etSecenekA.getText().toString();
        secenekB = etSecenekB.getText().toString();
        secenekC = etSecenekC.getText().toString();
        secenekD = etSecenekD.getText().toString();
        dogruSecenek = spnSecenek.getSelectedItem().toString();
        zorlukSeviyesi = spnZorlukSeviyesi.getSelectedItem().toString();

        Sorular soru = new Sorular(soruMetni, secenekA, secenekB, secenekC, secenekD, dogruSecenek, zorlukSeviyesi
        );

        try {
            dbHelper.soruekle(soru);
            Toast.makeText(this, "Soru veritabanına eklendi. \n Yeni soru ekleyebilirsiniz.",
                    Toast.LENGTH_SHORT).show();
            etSoruMetni.getText().clear();
            etSecenekA.getText().clear();
            etSecenekB.getText().clear();
            etSecenekC.getText().clear();
            etSecenekD.getText().clear();
            spnSecenek.setSelection(0);
            spnZorlukSeviyesi.setSelection(0);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Soru eklenemedi. HATA!", Toast.LENGTH_SHORT).show();
        }
    }

    public void btnSorulariListeleClick(View view) {
        Intent intent=new Intent(getApplicationContext(), SoruListelemeActivity.class);
        startActivity(intent);
    }
}