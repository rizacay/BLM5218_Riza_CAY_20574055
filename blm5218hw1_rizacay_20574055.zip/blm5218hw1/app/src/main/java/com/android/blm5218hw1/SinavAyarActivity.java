package com.android.blm5218hw1;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SinavAyarActivity extends AppCompatActivity {

    EditText etSinavSuresi, etSoruPuani;
    Spinner spnZorlukSeviyesi;
    String zorlukSeviyesi, sinavSuresi, soruPuani;
    ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_settings);
        etSinavSuresi = findViewById(R.id.etSinavSuresi);
        etSoruPuani = findViewById(R.id.etSoruPuani);
        spnZorlukSeviyesi = findViewById(R.id.spnZorlukSeviyesi);
        spdeKayitliVerileriGetir();
    }

    private void spdeKayitliVerileriGetir() {
        try {
            SharedPreferences sharedPref = this.getSharedPreferences("TestSettings", MODE_PRIVATE);
            etSinavSuresi.setText(sharedPref.getString("sinavSuresi", "Kayıt Yok"));
            etSoruPuani.setText(sharedPref.getString("soruPuani", "Kayıt Yok"));
            for (int i = 0; i < 5; i++) {
                if (spnZorlukSeviyesi.getItemAtPosition(i).equals(sharedPref.getString("zorlukSeviyesi", "Kayıt Yok"))) {
                    spnZorlukSeviyesi.setSelection(i);
                    return;
                }
            }
            Toast.makeText(this, "Kayıtlı Veriler Yüklendi. \n Değişim yapabilirsiniz.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            return;
        }
    }


    public void btnKaydetClick(View view) {

        sinavSuresi = etSinavSuresi.getText().toString();
        soruPuani = etSoruPuani.getText().toString();
        zorlukSeviyesi = spnZorlukSeviyesi.getSelectedItem().toString();

        SharedPreferences pref = this.getSharedPreferences("TestSettings", MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString("sinavSuresi", sinavSuresi);
        editor.putString("soruPuani", soruPuani);
        editor.putString("zorlukSeviyesi", zorlukSeviyesi);
        editor.commit();
        Toast.makeText(this, "Ayarlar Kaydedildi...", Toast.LENGTH_SHORT).show();
    }


    public void btnSinavOlustur2Click(View view) {
        Intent intent = new Intent(getApplicationContext(), SinavOlusturActivity.class);
        startActivity(intent);
    }
}