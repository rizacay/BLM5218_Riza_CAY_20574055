package com.android.blm5218hw1;

public class Sorular {
    private int ID;
    private String soru;
    private String secenekA;
    private String secenekB;
    private String secenekC;
    private String secenekD;
    private String dogruSecenek;
    private String zorlukSeviyesi;

    public Sorular() {
    }

    public Sorular(String soru, String secenekA, String secenekB, String secenekC,
                   String secenekD, String dogruSecenek, String zorlukSeviyesi) {
        this.soru = soru;
        this.secenekA = secenekA;
        this.secenekB = secenekB;
        this.secenekC = secenekC;
        this.secenekD = secenekD;
        this.dogruSecenek = dogruSecenek;
        this.zorlukSeviyesi = zorlukSeviyesi;
    }
    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getSoru() {
        return soru;
    }

    public void setSoru(String soru) {
        this.soru = soru;
    }

    public String getSecenekA() {
        return secenekA;
    }

    public void setSecenekA(String secenekA) {
        this.secenekA = secenekA;
    }

    public String getSecenekB() {
        return secenekB;
    }

    public void setSecenekB(String secenekB) {
        this.secenekB = secenekB;
    }

    public String getSecenekC() {
        return secenekC;
    }

    public void setSecenekC(String secenekC) {
        this.secenekC = secenekC;
    }

    public String getSecenekD() {
        return secenekD;
    }

    public void setSecenekD(String secenekD) {
        this.secenekD = secenekD;
    }

    public String getDogruSecenek() {
        return dogruSecenek;
    }

    public void setDogruSecenek(String dogruSecenek) {
        this.dogruSecenek = dogruSecenek;
    }

    public String getZorlukSeviyesi() {
        return zorlukSeviyesi;
    }

    public void setZorlukSeviyesi(String zorlukSeviyesi) {
        this.zorlukSeviyesi = zorlukSeviyesi;
    }
}
