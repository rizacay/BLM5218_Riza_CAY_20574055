package com.android.blm5218hw1;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SoruGuncelleActivity extends AppCompatActivity {
    EditText etSoruMetni, etSecenekA, etSecenekB, etSecenekC, etSecenekD;
    Spinner spnSecenek, spnZorlukSeviyesi;
    String soruMetni, secenekA, secenekB, secenekC, secenekD, dogruSecenek, zorlukSeviyesi;
    int idUpdate;
    Sorular q;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_question);
        etSoruMetni = findViewById(R.id.etSoruMetni);
        etSecenekA = findViewById(R.id.etSecenekA);
        etSecenekB = findViewById(R.id.etSecenekB);
        etSecenekC = findViewById(R.id.etSecenekC);
        etSecenekD = findViewById(R.id.etSecenekD);
        spnSecenek = findViewById(R.id.spnSecenek);
        spnZorlukSeviyesi = findViewById(R.id.spnZorlukSeviyesi);
    }

    @Override
    protected void onResume() {
        super.onResume();
        idUpdate = getIntent().getExtras().getInt("idUpdate");
        SinavDbHelper dbHelper = new SinavDbHelper(this, 1);
        q = dbHelper.guncellenecekSoruGetir(idUpdate);
        etSoruMetni.setText(q.getSoru());
        etSecenekA.setText(q.getSecenekA());
        etSecenekB.setText(q.getSecenekB());
        etSecenekC.setText(q.getSecenekC());
        etSecenekD.setText(q.getSecenekD());
        for (int i = 0; i < 4; i++) {
            if (spnSecenek.getItemAtPosition(i).equals(q.getDogruSecenek())) {
                spnSecenek.setSelection(i);
            }
        }
        for (int i = 0; i < 5; i++) {
            if (spnZorlukSeviyesi.getItemAtPosition(i).equals(q.getZorlukSeviyesi() + "")) {
                spnZorlukSeviyesi.setSelection(i);
                return;
            } else
                Log.i("Hatalar", "SoruGuncelleActivity onResume: Zorluk seviyesi HATA!");
        }
    }

    public void guncelleme(View view) {
        soruMetni = etSoruMetni.getText().toString();
        secenekA = etSecenekA.getText().toString();
        secenekB = etSecenekB.getText().toString();
        secenekC = etSecenekC.getText().toString();
        secenekD = etSecenekD.getText().toString();
        dogruSecenek = spnSecenek.getSelectedItem().toString();
        zorlukSeviyesi = spnZorlukSeviyesi.getSelectedItem().toString();
        Sorular q1 = new Sorular(soruMetni, secenekA, secenekB, secenekC, secenekD, dogruSecenek,
                zorlukSeviyesi);
        SinavDbHelper dbHelper = new SinavDbHelper(this, 1);
        long sonuc = dbHelper.soruGuncelle(q1, idUpdate);
        if (sonuc == -1) {
            Toast.makeText(this, "Soru Güncellemede HATA!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Soru Güncelleme BAŞARILI!", Toast.LENGTH_SHORT).show();
        }
    }

    public void btnListeClick(View view) {
        Intent intent = new Intent(getApplicationContext(), SoruListelemeActivity.class);
        startActivity(intent);
    }
}