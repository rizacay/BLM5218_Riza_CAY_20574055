package com.android.blm5218hw1;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class KullaniciGirisActivity extends AppCompatActivity {
    private ArrayList<Kullanicilar> kullanicilar;
    EditText etEmail, etSifre;
    int hatasayisi = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_login);
        if(!izinDurum()){
            izinIste();
        }
        etEmail = findViewById(R.id.etEmailLogin);
        etSifre = findViewById(R.id.etSifreLogin);
    }

    @Override
    protected void onResume() {
        super.onResume();
        try{
            SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(this);
            String jsonString = pref.getString("spAyarlar","");
            Gson gson = new Gson();
            Type type=new TypeToken<ArrayList<Kullanicilar>>(){}.getType();
           kullanicilar=gson.fromJson(jsonString,type);
        }
        catch(Exception e){
            e.printStackTrace();
        }

        if (kullanicilar == null)
            kullanicilar = new ArrayList<>();
    }

    public void btnGirisYapClick(View view) {
        String email = etEmail.getText().toString();
        String sifre = etSifre.getText().toString();
        if (uyeKayitliMiKontrol(email, sifre)) {
            Toast.makeText(this, "Giriş Başarılı!", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(getApplicationContext(), MenuEkraniActivity.class);
            startActivity(intent);
        } else {
            hatasayisi++;
            Toast.makeText(this, "Böyle bir kayıt bulunamadı. \n Bilgilerinizi Kontrol Edin" +
                            "\n Kalan deneme hakkı: " + (3 - hatasayisi),
                    Toast.LENGTH_SHORT).show();
            if (hatasayisi == 3)
                finish();
        }
    }

    public void btnKayitOlClick(View view) {
        Intent intent = new Intent(getApplicationContext(), KullaniciKayitActivity.class);
        startActivity(intent);
    }

    private boolean uyeKayitliMiKontrol(String email, String sifre) {
        boolean deger = false;
        for (Kullanicilar user : kullanicilar) {
            if (user.getEmail().toString().equals(email) && user.getSifre().toString().equals(sifre)) {
                deger = true;
            } else {
                deger = false;
            }
        }
        return deger;
    }

    private boolean izinDurum(){
        int haricidenOkumaIzni= ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE);
        int hariciyeYazmaIzni=ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE);
        return ((haricidenOkumaIzni== PackageManager.PERMISSION_GRANTED) && (hariciyeYazmaIzni==PackageManager.PERMISSION_GRANTED));
    }
    private void izinIste(){
        ActivityCompat.requestPermissions(this,
                new String[]{ Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE},5);
    }

}