package com.android.blm5218hw1;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class SinavSoruSecmeAdapter extends RecyclerView.Adapter<SinavSoruSecmeAdapter.RecyclerViewHolder> {

    interface OnItemCheckListener {
        void onItemCheck(Sorular question);
        void onItemUncheck(Sorular question);
    }
    @NonNull
    private OnItemCheckListener onItemClick;

    private SQLiteDatabase db;
    private static final String TAG = "SorularAdapter";
    ArrayList<Sorular> sorularArrayList;
    Context context;

    public SinavSoruSecmeAdapter(ArrayList<Sorular> sorularArrayList, Context context, @NonNull OnItemCheckListener onItemCheckListener) {
        this.sorularArrayList = sorularArrayList;
        this.context=context;
        this.onItemClick = onItemCheckListener;

    }
    @NonNull
    @Override
    public SinavSoruSecmeAdapter.RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater=LayoutInflater.from(parent.getContext());

        View view=layoutInflater.inflate(R.layout.layout_selectedrecyclerview_row , parent,false);
        return new SinavSoruSecmeAdapter.RecyclerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final SinavSoruSecmeAdapter.RecyclerViewHolder holder, final int position) {
        final Sorular currentItem = sorularArrayList.get(position);
        holder.tvSoru.setText((position+1)+") "+ sorularArrayList.get(position).getSoru());
        holder.tvDogruSecenek.setText(sorularArrayList.get(position).getDogruSecenek()+"");
        holder.tvA.setText(sorularArrayList.get(position).getSecenekA());
        holder.tvB.setText(sorularArrayList.get(position).getSecenekB());
        holder.tvC.setText(sorularArrayList.get(position).getSecenekC());
        holder.tvD.setText(sorularArrayList.get(position).getSecenekD());
        holder.tvZorlukSeviyesi.setText(sorularArrayList.get(position).getZorlukSeviyesi());

        holder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holder.cbSinavaEkle.setChecked(!holder.cbSinavaEkle.isChecked());
                if(holder.cbSinavaEkle.isChecked())
                    onItemClick.onItemCheck(currentItem);
                else
                    onItemClick.onItemUncheck(currentItem);
            }
        });
    }

    @Override
    public int getItemCount() {
        return sorularArrayList.size();
    }



    public class RecyclerViewHolder extends RecyclerView.ViewHolder{

        TextView tvSoru, tvDogruSecenek, tvA, tvB, tvC, tvD, tvZorlukSeviyesi;
        CheckBox cbSinavaEkle;
        public RecyclerViewHolder(@NonNull View itemView) {
            super(itemView);

            cbSinavaEkle=itemView.findViewById(R.id.cbSinavaEkle);
            tvSoru=itemView.findViewById(R.id.tvSoru);
            tvDogruSecenek=itemView.findViewById(R.id.tvDogruSecenek);
            tvA = itemView.findViewById(R.id.tvA);
            tvB = itemView.findViewById(R.id.tvB);
            tvC = itemView.findViewById(R.id.tvC);
            tvD = itemView.findViewById(R.id.tvD);
            tvZorlukSeviyesi = itemView.findViewById(R.id.tvZorlukSeviyesi);
            cbSinavaEkle.setClickable(false);

        }
        public void setOnClickListener(View.OnClickListener onClickListener) {
            itemView.setOnClickListener(onClickListener);
        }
    }
}