package com.android.blm5218hw1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class SinavOlusturActivity extends AppCompatActivity {
    EditText etSinavSuresi,etSoruPuani,etSinavZorlukDuzeyi;
    RecyclerView recyclerView;
    ArrayList<Sorular> liste;
    ArrayList<Sorular> seciliSorular;
    String DOSYA_ADI = "";
    File externaldosya;
    File externalDizin;
    File path;
    String kayitliSinavSuresi,kayitliSoruPuani,kayitlizorlukSeviyesi;
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_test);
        spdeKayitliVerileriGetir();
        db = this.openOrCreateDatabase("Sinavdb", MODE_PRIVATE, null);
        recyclerView=findViewById(R.id.recyclerView2);
        liste=getAllQuestions(kayitlizorlukSeviyesi);
        seciliSorular=new ArrayList<>();

        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(linearLayoutManager);

        SinavSoruSecmeAdapter adapter=new SinavSoruSecmeAdapter(liste,this,
                new SinavSoruSecmeAdapter.OnItemCheckListener() {
                    @Override
                    public void onItemCheck(Sorular soru) {
                        seciliSorular.add(soru);
                    }

                    @Override
                    public void onItemUncheck(Sorular question) {
                        seciliSorular.remove(question);
                    }
                });
        recyclerView.setAdapter(adapter);

        path = getFilesDir();
    }
    public String dateTimeFileName() {
        return "Sinav" + new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date()) + ".txt";
    }


    public ArrayList<Sorular> getAllQuestions(String zorlukDuzeyi) {
        ArrayList<Sorular> questionList = new ArrayList<>();

        String[] args={String.valueOf(zorlukDuzeyi)};
        Cursor c = db.rawQuery("SELECT * FROM " + TblSorular.TABLE_NAME +" WHERE zorlukSeviyesi=?",
                args);
        if (c.moveToFirst()) {
            do {
                Sorular question = new Sorular();
                question.setID(c.getInt(c.getColumnIndex(TblSorular.COLUMN_ID)));
                question.setSoru(c.getString(c.getColumnIndex(TblSorular.COLUMN_QUESTION)));
                question.setSecenekA(c.getString(c.getColumnIndex(TblSorular.COLUMN_OPTION1)));
                question.setSecenekB(c.getString(c.getColumnIndex(TblSorular.COLUMN_OPTION2)));
                question.setSecenekC(c.getString(c.getColumnIndex(TblSorular.COLUMN_OPTION3)));
                question.setSecenekD(c.getString(c.getColumnIndex(TblSorular.COLUMN_OPTION4)));
                question.setDogruSecenek(c.getString(c.getColumnIndex(TblSorular.COLUMN_ANSWER_NR)));
                question.setZorlukSeviyesi(c.getString(c.getColumnIndex(TblSorular.COLUMN_DIFF_LEVEL)));
                questionList.add(question);
            } while (c.moveToNext());
        }
        c.close();
        db.close();
        return questionList;
    }

    private void spdeKayitliVerileriGetir() {
        SharedPreferences sharedPref = this.getSharedPreferences("TestSettings",MODE_PRIVATE);
        kayitliSinavSuresi = sharedPref.getString("sinavSuresi","Kayıt Yok");
        kayitliSoruPuani = sharedPref.getString("soruPuani","Kayıt Yok");
        kayitlizorlukSeviyesi = sharedPref.getString("zorlukSeviyesi","Kayıt Yok");
        etSinavSuresi=findViewById(R.id.etSinavSuresi);
        etSoruPuani=findViewById(R.id.etSoruPuani);
        etSinavZorlukDuzeyi=findViewById(R.id.etSinavZorlukDuzeyi);
        etSinavSuresi.setText(kayitliSinavSuresi);
        etSoruPuani.setText(kayitliSoruPuani);
        etSinavZorlukDuzeyi.setText(kayitlizorlukSeviyesi);
    }

    public void btnSinavOlusturClick(View view) {
        String sb="Sınav Süreniz: " +kayitliSinavSuresi + "dkdır. \n";
        sb+="Her soru "+ kayitliSoruPuani +"  puandır. \n";
        for(Sorular soru:seciliSorular)
        {
            sb+=soru.getSoru() + "\n a) "
            +soru.getSecenekA()+ "\n b) "+soru.getSecenekB()+ "\n c) "+soru.getSecenekC()+ "\n d) "+soru.getSecenekD()+
                    "\n\n";
        }
        DOSYA_ADI = dateTimeFileName();
        if (!hariciKartIzinleriTamam())
            hariciKartIizinIste();

        File sdcard;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q){
            File[] externalStorageVolumes =
                    ContextCompat.getExternalFilesDirs(getApplicationContext(), null);
            sdcard = externalStorageVolumes[1];
        }
        else{
            sdcard = Environment.getExternalStorageDirectory();
        }

        externalDizin = new File(sdcard.getAbsolutePath() + "/SınavDosyalari/");
        externalDizin.mkdir();
        externaldosya = new File(externalDizin, "/"+DOSYA_ADI);
        try {
            FileOutputStream fos = new FileOutputStream(externaldosya);
            fos.write(sb.getBytes());
            fos.close();
            Toast.makeText(this, "Kayıt yeri: " + externaldosya,
                    Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "HATA KAYIT BAŞARISIZ.", Toast.LENGTH_SHORT).show();
        }
    }
    public void btnMailGonderClick(View view) {
        try {
            String filelocation = externaldosya+"";
            Intent intent = new Intent(Intent.ACTION_SENDTO);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_SUBJECT, "Sınav emaili");
            intent.putExtra(Intent.EXTRA_STREAM, Uri.parse( "file://"+filelocation));
            intent.putExtra(Intent.EXTRA_TEXT, "Sınav ektedir.");
            intent.setData(Uri.parse("mailto:abcd@gmail.com"));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch(Exception e)  {
            e.printStackTrace();
        }
    }

    private boolean hariciKartIzinleriTamam() {
        int haricikartakayit = ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE);
        int haricikartokuma = ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE);
        return haricikartakayit == PackageManager.PERMISSION_GRANTED && haricikartokuma == PackageManager.PERMISSION_GRANTED;
    }
    private void hariciKartIizinIste() {
        ActivityCompat.requestPermissions(this, new String[]{
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.READ_EXTERNAL_STORAGE
        }, 5);
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 5: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                    Toast.makeText(this, "İzin Verildi", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(this, "İzin Verilmedi", Toast.LENGTH_SHORT).show();
            }
        }
    }
    public static class TblSorular {
        public static final String TABLE_NAME = "TblSorular";
        public static final String COLUMN_ID = "id";
        public static final String COLUMN_QUESTION = "soru";
        public static final String COLUMN_OPTION1 = "secenekA";
        public static final String COLUMN_OPTION2 = "secenekB";
        public static final String COLUMN_OPTION3 = "secenekC";
        public static final String COLUMN_OPTION4 = "secenekD";
        public static final String COLUMN_ANSWER_NR = "dogruSecenek";
        public static final String COLUMN_DIFF_LEVEL = "zorlukSeviyesi";
    }
}